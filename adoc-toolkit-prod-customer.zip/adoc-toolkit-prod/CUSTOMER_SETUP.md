# ADOC Toolkit — Customer Quick Start

Minimal steps to set up and run this package on your machine.

## Prerequisites

- **Python 3.10+**
- **[uv](https://docs.astral.sh/uv/getting-started/installation/)** (recommended)

Install `uv` if needed:

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Windows (PowerShell)
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

## 1. Unpack

```bash
unzip adoc-toolkit-prod-customer.zip
cd adoc-toolkit-prod
```

## 2. Configure your tenant credentials

Copy the example and edit with **your** Acceldata URL and API keys:

```bash
cp config/environments.example.yaml config/environments.yaml
```

Edit `config/environments.yaml`:

```yaml
environments:
  my-tenant:
    name: "my-tenant"
    base_url: "https://YOUR-TENANT.acceldata.app"
    access_key: "YOUR_ACCESS_KEY"
    secret_key: "YOUR_SECRET_KEY"
    timezone: "UTC"   # or e.g. Asia/Kolkata

default_environment: "my-tenant"
```

Get keys from Acceldata: **API keys** in the product UI.  
Do **not** share or commit `config/environments.yaml`.

## 3. Install dependencies

```bash
uv sync
```

## 4. Run the interactive toolkit

```bash
uv run adoc-toolkit
```

Or:

```bash
bin/adoc-toolkit          # macOS / Linux
bin\adoc-toolkit.bat      # Windows
```

### First commands inside the shell

```text
ADOC > use my-tenant
ADOC > help
ADOC > get /catalog-server/api/data-sources
ADOC > get /catalog-server/api/assemblies
```

Replace `my-tenant` with the name you set in `environments.yaml`.

---

## Optional: list data sources, then select policies

Standalone script (stdlib only — no need for `uv` after unpacking if Python is available):

```bash
cp config/list_select_policies.example.json config/list_select_policies.local.json
# edit host / access_key / secret_key in the local file

python3 scripts/list_select_policies.py --config config/list_select_policies.local.json
```

Flow:

1. Select a **data source** (or `0` for all)
2. Choose a **policy type**
3. Select policies by line number (`1,3-5` or `a` for all)

More detail: `docs/list_select_policies.md`

---

## Troubleshooting

| Problem | What to do |
|---------|------------|
| `Could not load config/environments.yaml` | Create it from the example (step 2). Run commands from the `adoc-toolkit-prod` folder. |
| `No environment selected` | Run `use <your-env-name>` first. |
| `401` / `403` | Recheck `base_url`, `access_key`, and `secret_key`. Use `https` and no trailing slash on the URL. |
| `uv: command not found` | Install `uv` (see Prerequisites), or use `python3 -m pip install -e .` then `python3 -m adoc_toolkit`. |

---

## More documentation

- Full guide: `README.md`
- Environment setup: `docs/environment-setup.md`
- `get` command: `docs/get.md`
