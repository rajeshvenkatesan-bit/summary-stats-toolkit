"""Tests for ADOC toolkit."""
