#!/usr/bin/env python3
"""
List data sources, then list and select policies (stdlib only).

Interactive flow (data source is always the first step):
  1. Select a data source (scopes policies via assemblyIds; 0 = all)
  2. Select a policy type (or all types)
  3. List matching policies
  4. Select policies by line number / range / 'a' for all
  5. Print the selection (optional --output JSON file)

Credentials (any one source works, first match wins):
  - Environment variables:
      ACCELDATA_HOST / ADOC_HOST
      ACCELDATA_ACCESS_KEY / ADOC_ACCESS_KEY
      ACCELDATA_SECRET_KEY / ADOC_SECRET_KEY
      ACCELDATA_BEARER_TOKEN / ADOC_BEARER_TOKEN  (optional)
  - JSON config file via --config (see config/list_select_policies.example.json)
  - Toolkit environments.yaml via --env-name (config/environments.yaml)

Example (CS India):
  export ACCELDATA_HOST=https://cs-india.acceldata.app
  export ACCELDATA_ACCESS_KEY=YOUR_ACCESS_KEY
  export ACCELDATA_SECRET_KEY=YOUR_SECRET_KEY
  python3 scripts/list_select_policies.py
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

DEFAULT_DATASOURCE_PATH_CANDIDATES = (
    "catalog-server/api/assemblies",
    "catalog-server/api/metadata/datasources",
    "catalog-server/api/v1/datasources",
    "catalog-server/api/datasources",
    "catalog-server/api/data-sources",
    "admin/api/datasources",
)

POLICY_CHOICES = (
    ("Data Quality", "DATA_QUALITY"),
    ("Reconciliation", "RECONCILIATION,EQUALITY"),
    ("Freshness (Data Cadence)", "DATA_CADENCE"),
    ("Data Drift", "DATA_DRIFT"),
    ("Schema Drift", "SCHEMA_DRIFT"),
    ("Data Anomaly", "PROFILE_ANOMALY"),
)

ALL_POLICY_TYPES_LABEL = "All policy types"

RULE_STATUS_QUERIES = (
    "ENABLED,ACTIVE",
    "DISABLED",
)


def _cli_out(msg: str = "") -> None:
    print(msg, flush=True)


def normalize_host(host: str) -> str:
    return host.strip().rstrip("/")


class HttpResponse:
    def __init__(self, status_code: int, body: str) -> None:
        self.status_code = status_code
        self.text = body

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300

    def json(self) -> Any:
        return json.loads(self.text)

    def raise_for_status(self) -> None:
        if not self.ok:
            raise urllib.error.HTTPError(
                url="",
                code=self.status_code,
                msg=self.text[:500],
                hdrs=None,
                fp=None,
            )


class HttpClient:
    """Minimal HTTP client with Acceldata auth headers."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        self._headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "accessKey": str(cfg["access_key"]),
            "secretKey": str(cfg["secret_key"]),
        }
        token = (cfg.get("bearer_token") or "").strip()
        if token:
            self._headers["Authorization"] = "Bearer " + token

    def get(
        self,
        url: str,
        params: dict[str, Any] | None = None,
        timeout: float = 120.0,
    ) -> HttpResponse:
        if params:
            qs = urllib.parse.urlencode(
                {k: v for k, v in params.items() if v is not None}, doseq=True
            )
            url = url + ("&" if "?" in url else "?") + qs
        req = urllib.request.Request(url, headers=self._headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return HttpResponse(resp.getcode(), resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace") if e.fp else ""
            return HttpResponse(e.code, body)


def _env_first(*names: str) -> str:
    for name in names:
        val = os.environ.get(name, "").strip()
        if val:
            return val
    return ""


def load_config_from_env() -> dict[str, Any] | None:
    host = _env_first("ACCELDATA_HOST", "ADOC_HOST")
    access_key = _env_first("ACCELDATA_ACCESS_KEY", "ADOC_ACCESS_KEY")
    secret_key = _env_first("ACCELDATA_SECRET_KEY", "ADOC_SECRET_KEY")
    if not (host and access_key and secret_key):
        return None
    return {
        "host": normalize_host(host),
        "access_key": access_key,
        "secret_key": secret_key,
        "bearer_token": _env_first("ACCELDATA_BEARER_TOKEN", "ADOC_BEARER_TOKEN"),
    }


def load_config_from_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    host = data.get("host") or data.get("base_url")
    access_key = data.get("access_key")
    secret_key = data.get("secret_key")
    if not host or not access_key or not secret_key:
        raise SystemExit(
            f"Config {path} must include host (or base_url), access_key, secret_key"
        )
    return {
        "host": normalize_host(str(host)),
        "access_key": str(access_key),
        "secret_key": str(secret_key),
        "bearer_token": str(data.get("bearer_token") or ""),
    }


def load_config_from_environments_yaml(
    yaml_path: Path, env_name: str
) -> dict[str, Any]:
    """Minimal YAML reader for environments.yaml (no PyYAML required)."""
    text = yaml_path.read_text(encoding="utf-8")
    environments: dict[str, dict[str, str]] = {}
    current: str | None = None
    in_environments = False
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        if line.strip() == "environments:":
            in_environments = True
            current = None
            continue
        if not in_environments:
            continue
        if not line.startswith(" ") and not line.startswith("\t"):
            # left environments block
            break
        stripped = line.strip()
        indent = len(line) - len(line.lstrip(" "))
        if indent == 2 and stripped.endswith(":"):
            current = stripped[:-1]
            environments[current] = {}
            continue
        if current is None or ":" not in stripped:
            continue
        key, _, value = stripped.partition(":")
        value = value.strip().strip('"').strip("'")
        environments[current][key.strip()] = value

    if env_name not in environments:
        available = ", ".join(sorted(environments)) or "(none)"
        raise SystemExit(
            f"Environment '{env_name}' not found in {yaml_path}. Available: {available}"
        )
    env = environments[env_name]
    host = env.get("base_url") or env.get("host")
    access_key = env.get("access_key")
    secret_key = env.get("secret_key")
    if not host or not access_key or not secret_key:
        raise SystemExit(
            f"Environment '{env_name}' must define base_url, access_key, secret_key"
        )
    return {
        "host": normalize_host(host),
        "access_key": access_key,
        "secret_key": secret_key,
        "bearer_token": env.get("bearer_token", ""),
    }


def resolve_config_path(config_arg: str, project_root: Path) -> Path:
    """Resolve --config against cwd, then project root (adoc-toolkit-prod/)."""
    raw = Path(config_arg).expanduser()
    candidates = []
    if raw.is_absolute():
        candidates.append(raw)
    else:
        candidates.append((Path.cwd() / raw).resolve())
        candidates.append((project_root / raw).resolve())
        # When run from scripts/, also allow bare filename under config/
        candidates.append((project_root / "config" / raw.name).resolve())
    for path in candidates:
        if path.is_file():
            return path
    tried = "\n  ".join(str(p) for p in candidates)
    raise SystemExit(
        f"Config file not found: {config_arg}\nTried:\n  {tried}\n\n"
        "Create it with:\n"
        "  cp config/list_select_policies.example.json "
        "config/list_select_policies.local.json\n"
        "then fill in access_key / secret_key."
    )


def resolve_config(args: argparse.Namespace, project_root: Path) -> dict[str, Any]:
    if args.config:
        return load_config_from_json(resolve_config_path(args.config, project_root))
    if args.env_name:
        yaml_path = Path(args.environments_file).expanduser().resolve()
        if not yaml_path.is_file():
            raise SystemExit(
                f"environments file not found: {yaml_path}\n"
                "Create config/environments.yaml (see docs/environment-setup.md) "
                "or pass --config / use ACCELDATA_* env vars."
            )
        return load_config_from_environments_yaml(yaml_path, args.env_name)
    cfg = load_config_from_env()
    if cfg:
        return cfg
    # Convenience: if environments.yaml exists and only one env, or default cs-india
    default_yaml = project_root / "config" / "environments.yaml"
    if default_yaml.is_file() and args.env_name is None:
        raise SystemExit(
            "No credentials found.\n\n"
            "Set ACCELDATA_HOST / ACCELDATA_ACCESS_KEY / ACCELDATA_SECRET_KEY,\n"
            "or pass --config path/to.json,\n"
            f"or pass --env-name <name> (reads {default_yaml}).\n\n"
            "For CS India testing see docs/list_select_policies.md"
        )
    raise SystemExit(
        "No credentials found. Set ACCELDATA_HOST, ACCELDATA_ACCESS_KEY, "
        "ACCELDATA_SECRET_KEY (see docs/list_select_policies.md)."
    )


def _extract_list_of_dicts(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if not isinstance(payload, dict):
        return []
    for key in (
        "content",
        "items",
        "data",
        "rules",
        "results",
        "value",
        "records",
        "elements",
    ):
        inner = payload.get(key)
        if isinstance(inner, list) and inner and isinstance(inner[0], dict):
            return [x for x in inner if isinstance(x, dict)]
    best: list[dict[str, Any]] = []
    for _k, v in payload.items():
        if isinstance(v, list) and v and isinstance(v[0], dict):
            cand = [x for x in v if isinstance(x, dict)]
            if len(cand) > len(best):
                best = cand
    return best


def fetch_datasources(
    client: HttpClient, host: str, timeout: float
) -> tuple[list[dict[str, Any]], str]:
    host = normalize_host(host)
    last_resp: HttpResponse | None = None
    for path in DEFAULT_DATASOURCE_PATH_CANDIDATES:
        url = host + "/" + path.lstrip("/")
        try:
            r = client.get(url, params=None, timeout=timeout)
        except (urllib.error.URLError, TimeoutError, OSError):
            continue
        last_resp = r
        if r.status_code == 404 or not r.ok:
            continue
        try:
            body = r.json()
        except ValueError:
            continue
        rows = _extract_list_of_dicts(body)
        if rows:
            return rows, path
    if last_resp is not None:
        last_resp.raise_for_status()
    raise RuntimeError("Could not load data sources from any known path.")


def _datasource_label(row: dict[str, Any]) -> str:
    for k in (
        "name",
        "assembly",
        "datasourceName",
        "dataSourceName",
        "displayName",
        "uid",
        "username",
        "email",
    ):
        v = row.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    rid = row.get("id") or row.get("assemblyId")
    return str(rid) if rid is not None else repr(row)[:80]


def _assembly_ids_from_datasource(row: dict[str, Any]) -> str | None:
    # Prefer explicit assembly id fields before generic id
    for k in ("assemblyIds", "assemblyId", "assembly_ids"):
        v = row.get(k)
        if v is None:
            continue
        if isinstance(v, list):
            parts = [str(x).strip() for x in v if str(x).strip()]
            if parts:
                return ",".join(parts)
        s = str(v).strip()
        if s:
            return s
    rid = row.get("id")
    if rid is not None and str(rid).strip():
        return str(rid).strip()
    return None

def prompt_choice(
    title: str, items: list[tuple[str, Any]], *, allow_zero: bool = False
) -> Any | None:
    _cli_out("\n" + title)
    for i, (label, _val) in enumerate(items, start=1):
        _cli_out(f"  {i}. {label}")
    if allow_zero:
        _cli_out("  0. Skip / all (no data-source filter)")
    while True:
        raw = input("Enter number: ").strip()
        try:
            idx = int(raw)
        except ValueError:
            _cli_out("Please enter a number.")
            continue
        if allow_zero and idx == 0:
            return None
        if 1 <= idx <= len(items):
            return items[idx - 1][1]
        _cli_out("Out of range. Try again.")


def prompt_policy_type() -> tuple[str, str | None]:
    _cli_out("\nChoose policy type:")
    for i, (label, _rtq) in enumerate(POLICY_CHOICES, start=1):
        _cli_out(f"  {i}. {label}")
    all_idx = len(POLICY_CHOICES) + 1
    _cli_out(f"  {all_idx}. {ALL_POLICY_TYPES_LABEL}")
    while True:
        raw = input(f"Enter number (1–{all_idx}): ").strip()
        try:
            idx = int(raw)
        except ValueError:
            _cli_out(f"Please enter a number from 1 to {all_idx}.")
            continue
        if 1 <= idx <= len(POLICY_CHOICES):
            label, rtq = POLICY_CHOICES[idx - 1]
            return label, rtq
        if idx == all_idx:
            return ALL_POLICY_TYPES_LABEL, None
        _cli_out("Out of range. Try again.")


def inner_rule(row: dict[str, Any]) -> dict[str, Any]:
    r = row.get("rule")
    return r if isinstance(r, dict) else row


def rule_id(rule: dict[str, Any]) -> Any:
    return rule.get("id")


def rule_name(rule: dict[str, Any]) -> str:
    name = rule.get("name")
    return name.strip() if isinstance(name, str) else "(unnamed)"


def rule_type(rule: dict[str, Any]) -> str:
    t = rule.get("type") or rule.get("ruleType") or ""
    return str(t).strip().upper()


def rule_is_enabled(rule: dict[str, Any]) -> bool:
    if rule.get("archived") is True:
        return False
    for key in ("enable", "enabled"):
        val = rule.get(key)
        if val is not None:
            return bool(val)
    st = rule.get("status")
    if isinstance(st, str) and st.upper() == "DISABLED":
        return False
    return True


def _fetch_rules_page(
    client: HttpClient,
    host: str,
    *,
    rule_type_query: str | None,
    rule_status: str,
    page: int,
    page_size: int,
    timeout: float,
    extra: dict[str, Any],
) -> list[dict[str, Any]]:
    host = normalize_host(host)
    url = host + "/catalog-server/api/rules"
    params: dict[str, Any] = {
        "page": page,
        "size": page_size,
        "withLatestExecution": "true",
        "sortBy": "updatedAt:DESC",
        "ruleStatus": rule_status,
    }
    if rule_type_query:
        params["ruleType"] = rule_type_query
    params.update(extra)
    r = client.get(url, params=params, timeout=timeout)
    r.raise_for_status()
    return _extract_list_of_dicts(r.json())


def fetch_rules(
    client: HttpClient,
    host: str,
    *,
    rule_type_query: str | None,
    page_size: int,
    timeout: float,
    extra_params: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    extra = dict(extra_params or {})
    merged: dict[str, dict[str, Any]] = {}
    for rule_status in RULE_STATUS_QUERIES:
        page = 0
        while True:
            chunk = _fetch_rules_page(
                client,
                host,
                rule_type_query=rule_type_query,
                rule_status=rule_status,
                page=page,
                page_size=page_size,
                timeout=timeout,
                extra=extra,
            )
            if not chunk:
                break
            for row in chunk:
                inner = inner_rule(row)
                rid = rule_id(inner)
                if rid is not None and str(rid) not in merged:
                    merged[str(rid)] = row
            if len(chunk) < page_size:
                break
            page += 1
    return list(merged.values())


def parse_pick_indices(s: str, n: int) -> set[int]:
    chosen: set[int] = set()
    for part in s.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            lo, hi = int(a), int(b)
            for i in range(lo, hi + 1):
                idx = i - 1
                if 0 <= idx < n:
                    chosen.add(idx)
        else:
            idx = int(part) - 1
            if 0 <= idx < n:
                chosen.add(idx)
    return chosen


def prompt_pick_indices(n: int) -> set[int] | None:
    _cli_out(
        "\nSelect policies:\n"
        "  Enter line numbers (e.g. 1,3-5), 'a' for all listed, or blank to cancel:"
    )
    while True:
        raw = input("> ").strip()
        if not raw:
            return None
        if raw.lower() == "a":
            return set(range(n))
        try:
            chosen = parse_pick_indices(raw, n)
        except ValueError:
            _cli_out("Invalid input. Use comma-separated numbers and ranges, e.g. 1,3-5.")
            continue
        if not chosen:
            _cli_out("No valid line numbers in range. Try again.")
            continue
        return chosen


def print_rule_list(rules: list[dict[str, Any]]) -> None:
    enabled_n = sum(1 for r in rules if rule_is_enabled(r))
    disabled_n = len(rules) - enabled_n
    _cli_out(
        f"\nFound {len(rules)} policy/policies "
        f"({enabled_n} enabled, {disabled_n} disabled):\n"
    )
    for i, rule in enumerate(rules, 1):
        en = "enabled" if rule_is_enabled(rule) else "disabled"
        _cli_out(
            f"  {i:3d}. id={rule_id(rule)}  type={rule_type(rule)}  "
            f"{en:<8}  name={rule_name(rule)}"
        )


def build_arg_parser(project_root: Path) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "List data sources first, then list and select policies "
            "(scoped by assemblyIds)."
        )
    )
    p.add_argument(
        "--config",
        help="JSON config with host, access_key, secret_key "
        "(see config/list_select_policies.example.json)",
    )
    p.add_argument(
        "--env-name",
        help="Environment name from environments.yaml (e.g. cs-india)",
    )
    p.add_argument(
        "--environments-file",
        default=str(project_root / "config" / "environments.yaml"),
        help="Path to environments.yaml (default: config/environments.yaml)",
    )
    p.add_argument(
        "--datasource-index",
        type=int,
        help="Non-interactive: 1-based data source index (0 = skip / all)",
    )
    p.add_argument(
        "--policy-type",
        type=int,
        help="Non-interactive: 1-based policy type index "
        f"(1–{len(POLICY_CHOICES)}, or {len(POLICY_CHOICES) + 1} = all)",
    )
    p.add_argument(
        "--select",
        help="Non-interactive policy selection: 'a' or '1,3-5'",
    )
    p.add_argument(
        "--output",
        help="Write selected policies JSON to this path",
    )
    p.add_argument(
        "--page-size",
        type=int,
        default=100,
        help="Rules list page size (default: 100)",
    )
    p.add_argument(
        "--timeout",
        type=float,
        default=120.0,
        help="HTTP timeout seconds (default: 120)",
    )
    return p


def main(argv: list[str] | None = None) -> int:
    project_root = Path(__file__).resolve().parent.parent
    args = build_arg_parser(project_root).parse_args(argv)
    cfg = resolve_config(args, project_root)
    host = cfg["host"]
    timeout = float(args.timeout)
    page_size = int(args.page_size)
    client = HttpClient(cfg)

    _cli_out(f"Tenant: {host}")
    _cli_out("Loading data sources…")
    datasources, ds_path = fetch_datasources(
        client, host, timeout=min(timeout, 60.0)
    )
    _cli_out(f"Loaded {len(datasources)} data source(s) (via …/{ds_path}).")

    ds_items = [
        (f"{_datasource_label(d)} (id={d.get('id')!r})", d) for d in datasources
    ]

    if args.datasource_index is not None:
        idx = args.datasource_index
        if idx == 0:
            selected_ds = None
        elif 1 <= idx <= len(ds_items):
            selected_ds = ds_items[idx - 1][1]
            _cli_out(f"Using data source: {_datasource_label(selected_ds)}")
        else:
            raise SystemExit(
                f"--datasource-index out of range (0 or 1–{len(ds_items)})"
            )
    else:
        selected_ds = prompt_choice(
            "Select a data source (policies scoped via assemblyIds):",
            ds_items,
            allow_zero=True,
        )

    list_extra: dict[str, Any] = {}
    ds_label = "(all / no filter)"
    if selected_ds is not None:
        ds_label = _datasource_label(selected_ds)
        assembly_csv = _assembly_ids_from_datasource(selected_ds)
        if assembly_csv:
            list_extra["assemblyIds"] = assembly_csv
        else:
            print(
                "Warning: could not resolve assemblyIds from data source row; "
                "listing without assemblyIds filter.",
                file=sys.stderr,
            )

    if args.policy_type is not None:
        idx = args.policy_type
        if 1 <= idx <= len(POLICY_CHOICES):
            scope_label, rule_type_query = POLICY_CHOICES[idx - 1]
        elif idx == len(POLICY_CHOICES) + 1:
            scope_label, rule_type_query = ALL_POLICY_TYPES_LABEL, None
        else:
            raise SystemExit(
                f"--policy-type out of range (1–{len(POLICY_CHOICES) + 1})"
            )
    else:
        scope_label, rule_type_query = prompt_policy_type()

    rt_desc = rule_type_query if rule_type_query else "(all types)"
    asm_desc = list_extra.get("assemblyIds", "(none)")
    _cli_out(
        f"\nFetching policies — data source: {ds_label}; "
        f"assemblyIds: {asm_desc}; type: {scope_label}; ruleType={rt_desc} …"
    )

    rows = fetch_rules(
        client,
        host,
        rule_type_query=rule_type_query,
        page_size=page_size,
        timeout=timeout,
        extra_params=list_extra or None,
    )
    rules = [inner_rule(r) for r in rows]

    if not rules:
        _cli_out("No policies found for the selected scope.")
        return 0

    print_rule_list(rules)

    if args.select is not None:
        raw = args.select.strip()
        if raw.lower() == "a":
            indices = set(range(len(rules)))
        else:
            try:
                indices = parse_pick_indices(raw, len(rules))
            except ValueError as e:
                raise SystemExit(f"Invalid --select value: {e}") from e
            if not indices:
                raise SystemExit("No valid line numbers in --select")
    else:
        indices = prompt_pick_indices(len(rules))
        if indices is None:
            _cli_out("Aborted.")
            return 0

    selected = [rules[i] for i in sorted(indices)]
    _cli_out(f"\nSelected {len(selected)} policy/policies:\n")
    payload = []
    for rule in selected:
        item = {
            "id": rule_id(rule),
            "name": rule_name(rule),
            "type": rule_type(rule),
            "enabled": rule_is_enabled(rule),
            "datasource": ds_label,
            "assemblyIds": list_extra.get("assemblyIds"),
        }
        payload.append(item)
        _cli_out(
            f"  id={item['id']}  type={item['type']}  "
            f"{'enabled' if item['enabled'] else 'disabled':<8}  name={item['name']}"
        )

    if args.output:
        out_path = Path(args.output).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        _cli_out(f"\nWrote selection to {out_path}")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        _cli_out("\nInterrupted.")
        raise SystemExit(130)
