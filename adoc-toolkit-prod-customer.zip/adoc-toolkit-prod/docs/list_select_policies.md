# List & select policies (data source first)

Standalone script under `adoc-toolkit-prod` that **always starts with data sources**, then lists and lets you select policies. It does **not** change existing toolkit commands or files.

## What it does

1. **Select a data source** (optional skip with `0` = all / no `assemblyIds` filter)
2. **Choose a policy type** (DQ, Reconciliation, Freshness, Drift, Anomaly, or all)
3. **List policies** from `GET /catalog-server/api/rules` scoped with `assemblyIds`
4. **Select policies** by line numbers (`1,3-5`), `a` for all, or blank to cancel
5. Print the selection (optionally write JSON with `--output`)

## Files

| Path | Purpose |
|------|---------|
| `scripts/list_select_policies.py` | Interactive list/select script (stdlib only) |
| `config/list_select_policies.example.json` | CS India host template for `--config` |
| `docs/list_select_policies.md` | This guide |

## CS India (test tenant)

Use the **CS India** Acceldata tenant:

| Field | Value |
|--------|--------|
| **Host** | `https://cs-india.acceldata.app` |
| **Access key** | From Acceldata UI → API keys (CS India) |
| **Secret key** | Paired secret from the same API keys screen |
| **Timezone (optional)** | `Asia/Kolkata` if you also use toolkit exports |

Do **not** commit real keys. Copy the example config and fill locally:

```bash
cd adoc-toolkit-prod
cp config/list_select_policies.example.json config/list_select_policies.local.json
# edit config/list_select_policies.local.json with your CS India keys
```

Or set environment variables:

```bash
export ACCELDATA_HOST=https://cs-india.acceldata.app
export ACCELDATA_ACCESS_KEY='YOUR_ACCESS_KEY'
export ACCELDATA_SECRET_KEY='YOUR_SECRET_KEY'
```

Optional toolkit-style setup (`config/environments.yaml`, gitignored):

```yaml
environments:
  cs-india:
    name: "cs-india"
    base_url: "https://cs-india.acceldata.app"
    access_key: "YOUR_ACCESS_KEY"
    secret_key: "YOUR_SECRET_KEY"
    timezone: "Asia/Kolkata"

default_environment: "cs-india"
```

## How to run (test on CS India)

From the `adoc-toolkit-prod` directory:

### Option A — env vars

```bash
export ACCELDATA_HOST=https://cs-india.acceldata.app
export ACCELDATA_ACCESS_KEY='YOUR_ACCESS_KEY'
export ACCELDATA_SECRET_KEY='YOUR_SECRET_KEY'

python3 scripts/list_select_policies.py
```

### Option B — JSON config

```bash
cp config/list_select_policies.example.json config/list_select_policies.local.json
# paste CS India keys into the local file

python3 scripts/list_select_policies.py --config config/list_select_policies.local.json
```

### Option C — environments.yaml

```bash
python3 scripts/list_select_policies.py --env-name cs-india
```

### Interactive prompts you should see

1. `Loading data sources…` then a numbered list  
2. `Select a data source …` (enter a number; `0` skips filter)  
3. `Choose policy type:`  
4. Numbered policies, then `Select policies:` (`1,3-5` / `a`)

### Non-interactive smoke test (first data source, DQ, select first policy)

```bash
python3 scripts/list_select_policies.py \
  --config config/list_select_policies.local.json \
  --datasource-index 1 \
  --policy-type 1 \
  --select 1 \
  --output /tmp/selected_policies_cs_india.json
```

That command **only lists/selects policies**. It does **not** export execution metrics.

### Execution metrics for one data source (standalone)

Prefer `--datasource-name` (stable) over `--datasource-index` (menu order can change).

```bash
uv run python scripts/list_select_policies.py \
  --config config/list_select_policies.local.json \
  --datasource-name kiranbq \
  --policy-type 1 \
  --export-execution-metrics \
  --backload -45d \
  --metrics-output-dir ./output/execution-metrics
```

This calls the same exporter as:

```text
ADOC > export-execution-metrics --datasource-name kiranbq --policy-types DATA_QUALITY --backload -45d
```

Flags:

| Flag | Meaning |
|------|---------|
| `--datasource-name NAME` | Select data source by name (preferred) |
| `--datasource-index N` | `1` = first DS; `0` = no DS filter |
| `--policy-type N` | `1` = Data Quality … `7` = all types |
| `--select 1,3-5` or `a` | Pick policies without a prompt |
| `--output path.json` | Write selected policy summary JSON |
| `--export-execution-metrics` | Export execution metrics for the selected data source |
| `--backload -45d` | Metrics lookback (max `-60d`) |
| `--metrics-policy-types` | Override types, e.g. `DATA_QUALITY,EQUALITY` |
| `--metrics-output-dir` | CSV output directory |
| `--skip-policy-select` | Skip policy list/select (metrics only) |

## APIs used

- Data sources: tries `catalog-server/api/assemblies`, then other datasource paths
- Policies: `GET /catalog-server/api/rules?assemblyIds=…&ruleType=…&ruleStatus=…`

Auth headers: `accessKey` + `secretKey` (same as the rest of ADOC Toolkit).

## Notes

- Policy list/select is read-only (no enable/disable/trigger).
- `--export-execution-metrics` needs toolkit deps (`uv sync`) and uses the same `export-execution-metrics` code as the interactive shell.
- List/select-only mode needs **Python 3.10+** only.
